'use client';

import React, { useRef, useState, useEffect } from 'react';
import { Camera, X, Check } from 'lucide-react';

interface CameraCaptureProps {
  onCapture: (file: File) => void;
  onClose: () => void;
}

export function CameraCapture({ onCapture, onClose }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [photoData, setPhotoData] = useState<string | null>(null);

  useEffect(() => {
    async function setupCamera() {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (err) {
        console.error('Error accessing camera:', err);
        alert('Could not access camera. Please check permissions.');
        onClose();
      }
    }
    setupCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        setPhotoData(dataUrl);
      }
    }
  };

  const confirmPhoto = () => {
    if (photoData) {
      // Convert dataUrl to File
      fetch(photoData)
        .then((res) => res.blob())
        .then((blob) => {
          const file = new File([blob], `scan_${Date.now()}.jpg`, { type: 'image/jpeg' });
          onCapture(file);
        });
    }
  };

  const retakePhoto = () => {
    setPhotoData(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      <div className="flex justify-between items-center p-4 text-white">
        <button onClick={onClose} className="p-2 rounded-full bg-white/20 hover:bg-white/30">
          <X className="w-6 h-6" />
        </button>
        <span className="font-medium">{photoData ? 'Preview' : 'Take Photo'}</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 relative overflow-hidden flex items-center justify-center bg-black">
        {photoData ? (
          <img src={photoData} alt="Captured" className="max-h-full max-w-full object-contain" />
        ) : (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="max-h-full max-w-full object-cover"
          />
        )}
        <canvas ref={canvasRef} className="hidden" />
      </div>

      <div className="p-6 pb-12 flex justify-center items-center gap-8">
        {photoData ? (
          <>
            <button
              onClick={retakePhoto}
              className="px-6 py-3 rounded-full bg-white/20 text-white font-medium"
            >
              Retake
            </button>
            <button
              onClick={confirmPhoto}
              className="px-6 py-3 rounded-full bg-indigo-600 text-white font-medium flex items-center gap-2"
            >
              <Check className="w-5 h-5" /> Use Photo
            </button>
          </>
        ) : (
          <button
            onClick={takePhoto}
            className="w-20 h-20 rounded-full border-4 border-white flex items-center justify-center"
          >
            <div className="w-16 h-16 rounded-full bg-white"></div>
          </button>
        )}
      </div>
    </div>
  );
}
