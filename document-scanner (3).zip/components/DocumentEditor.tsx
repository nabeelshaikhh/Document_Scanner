'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Save, Download, PenTool, X, Trash2, Bold, Italic, Underline } from 'lucide-react';
import { useDocuments } from '@/lib/context';
import { useRouter } from 'next/navigation';
import SignatureCanvas from 'react-signature-canvas';
import jsPDF from 'jspdf';

interface DocumentEditorProps {
  initialContent: string;
  onDiscard: () => void;
}

export function DocumentEditor({ initialContent, onDiscard }: DocumentEditorProps) {
  const [title, setTitle] = useState('Untitled Document');
  const [content, setContent] = useState(initialContent);
  const [isSignatureModalOpen, setIsSignatureModalOpen] = useState(false);
  const [signatureData, setSignatureData] = useState<string | null>(null);
  const sigCanvas = useRef<SignatureCanvas>(null);
  const { addDocument } = useDocuments();
  const router = useRouter();
  const editorRef = useRef<HTMLDivElement>(null);

  // Initialize contentEditable
  useEffect(() => {
    if (editorRef.current && !editorRef.current.innerHTML) {
      // Convert basic newlines to paragraphs for better editing
      const htmlContent = initialContent
        .split('\n\n')
        .map(p => `<p>${p.replace(/\n/g, '<br/>')}</p>`)
        .join('');
      editorRef.current.innerHTML = htmlContent;
    }
  }, [initialContent]);

  const handleFormat = (command: string) => {
    document.execCommand(command, false, undefined);
    editorRef.current?.focus();
  };

  const handleSave = () => {
    const finalContent = editorRef.current?.innerHTML || content;
    addDocument({
      id: Date.now().toString(),
      title,
      content: finalContent,
      createdAt: Date.now(),
      signature: signatureData || undefined,
    });
    router.push('/history');
  };

  const clearSignature = () => {
    sigCanvas.current?.clear();
  };

  const applySignature = () => {
    if (sigCanvas.current && !sigCanvas.current.isEmpty()) {
      setSignatureData(sigCanvas.current.toDataURL('image/png'));
      setIsSignatureModalOpen(false);
    }
  };

  const exportPDF = () => {
    const doc = new jsPDF();
    const finalContent = editorRef.current?.innerText || content;
    
    doc.setFontSize(16);
    doc.text(title, 20, 20);
    
    doc.setFontSize(12);
    const splitText = doc.splitTextToSize(finalContent, 170);
    doc.text(splitText, 20, 30);
    
    if (signatureData) {
      // Add signature at the bottom
      const yPos = Math.min(280, 30 + (splitText.length * 7) + 20);
      doc.addImage(signatureData, 'PNG', 20, yPos, 50, 25);
    }
    
    doc.save(`${title.replace(/\s+/g, '_')}.pdf`);
  };

  const exportTXT = () => {
    const finalContent = editorRef.current?.innerText || content;
    const blob = new Blob([finalContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title.replace(/\s+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 pb-24">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="flex items-center justify-between p-4">
          <button onClick={onDiscard} className="p-2 text-gray-500 hover:text-gray-900 rounded-full hover:bg-gray-100">
            <X className="w-5 h-5" />
          </button>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="text-center font-medium text-gray-900 bg-transparent border-none focus:ring-0 w-1/2"
            placeholder="Document Title"
          />
          <button onClick={handleSave} className="p-2 text-indigo-600 hover:text-indigo-700 font-medium">
            Save
          </button>
        </div>
        
        {/* Formatting Toolbar */}
        <div className="flex items-center justify-center gap-2 p-2 bg-gray-50 border-t border-gray-100">
          <button onClick={() => handleFormat('bold')} className="p-2 text-gray-600 hover:bg-gray-200 rounded">
            <Bold className="w-4 h-4" />
          </button>
          <button onClick={() => handleFormat('italic')} className="p-2 text-gray-600 hover:bg-gray-200 rounded">
            <Italic className="w-4 h-4" />
          </button>
          <button onClick={() => handleFormat('underline')} className="p-2 text-gray-600 hover:bg-gray-200 rounded">
            <Underline className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="flex-1 p-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 min-h-[60vh] p-6">
          <div
            ref={editorRef}
            contentEditable
            className="outline-none min-h-[50vh] prose prose-sm max-w-none"
            onInput={(e) => setContent(e.currentTarget.innerHTML)}
          />
          
          {signatureData && (
            <div className="mt-12 border-t border-gray-100 pt-8 relative group">
              <p className="text-sm text-gray-400 mb-2">Signature:</p>
              <img src={signatureData} alt="Signature" className="h-20 object-contain" />
              <button 
                onClick={() => setSignatureData(null)}
                className="absolute top-8 right-0 p-2 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="fixed bottom-20 left-0 right-0 max-w-md mx-auto p-4 bg-white border-t border-gray-200 flex gap-4">
        <button
          onClick={() => setIsSignatureModalOpen(true)}
          className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-gray-200"
        >
          <PenTool className="w-4 h-4" />
          Sign
        </button>
        <button
          onClick={exportPDF}
          className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-indigo-700"
        >
          <Download className="w-4 h-4" />
          Export PDF
        </button>
      </div>

      {/* Signature Modal */}
      {isSignatureModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-gray-100 flex justify-between items-center">
              <h3 className="font-medium text-gray-900">Add Signature</h3>
              <button onClick={() => setIsSignatureModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 bg-gray-50">
              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                <SignatureCanvas
                  ref={sigCanvas}
                  penColor="black"
                  canvasProps={{ className: 'w-full h-48' }}
                />
              </div>
            </div>
            <div className="p-4 flex gap-3">
              <button
                onClick={clearSignature}
                className="flex-1 py-2 text-gray-600 font-medium hover:bg-gray-100 rounded-lg"
              >
                Clear
              </button>
              <button
                onClick={applySignature}
                className="flex-1 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
