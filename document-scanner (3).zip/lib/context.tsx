'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export interface DocumentData {
  id: string;
  title: string;
  content: string;
  createdAt: number;
  signature?: string;
}

interface DocumentContextType {
  documents: DocumentData[];
  addDocument: (doc: DocumentData) => void;
  deleteDocument: (id: string) => void;
  updateDocument: (id: string, doc: Partial<DocumentData>) => void;
}

const DocumentContext = createContext<DocumentContextType | undefined>(undefined);

export function DocumentProvider({ children }: { children: React.ReactNode }) {
  const [documents, setDocuments] = useState<DocumentData[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('doc-scanner-history');
    if (saved) {
      try {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setDocuments(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to parse history', e);
      }
    }
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem('doc-scanner-history', JSON.stringify(documents));
    }
  }, [documents, isLoaded]);

  const addDocument = (doc: DocumentData) => {
    setDocuments((prev) => [doc, ...prev]);
  };

  const deleteDocument = (id: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== id));
  };

  const updateDocument = (id: string, updatedDoc: Partial<DocumentData>) => {
    setDocuments((prev) =>
      prev.map((d) => (d.id === id ? { ...d, ...updatedDoc } : d))
    );
  };

  return (
    <DocumentContext.Provider value={{ documents, addDocument, deleteDocument, updateDocument }}>
      {children}
    </DocumentContext.Provider>
  );
}

export function useDocuments() {
  const context = useContext(DocumentContext);
  if (context === undefined) {
    throw new Error('useDocuments must be used within a DocumentProvider');
  }
  return context;
}
