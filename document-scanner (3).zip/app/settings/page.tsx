'use client';

import React from 'react';
import { Settings, User, Shield, Bell, HelpCircle, LogOut } from 'lucide-react';

export default function SettingsPage() {
  return (
    <div className="p-6 flex flex-col min-h-screen bg-gray-50 pb-24">
      <header className="mb-6 mt-4">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-500 text-sm mt-1">Manage your preferences</p>
      </header>

      <div className="space-y-6">
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="p-4 flex items-center gap-4 border-b border-gray-100">
            <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold text-lg">
              U
            </div>
            <div>
              <h3 className="font-medium text-gray-900">User Account</h3>
              <p className="text-sm text-gray-500">user@example.com</p>
            </div>
          </div>
          <div className="p-2">
            <button className="w-full flex items-center justify-between p-3 text-left hover:bg-gray-50 rounded-xl transition-colors">
              <div className="flex items-center gap-3">
                <User className="w-5 h-5 text-gray-400" />
                <span className="text-gray-700 font-medium">Edit Profile</span>
              </div>
            </button>
            <button className="w-full flex items-center justify-between p-3 text-left hover:bg-gray-50 rounded-xl transition-colors">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-gray-400" />
                <span className="text-gray-700 font-medium">Privacy & Security</span>
              </div>
            </button>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden p-2">
          <button className="w-full flex items-center justify-between p-3 text-left hover:bg-gray-50 rounded-xl transition-colors">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-gray-400" />
              <span className="text-gray-700 font-medium">Notifications</span>
            </div>
          </button>
          <button className="w-full flex items-center justify-between p-3 text-left hover:bg-gray-50 rounded-xl transition-colors">
            <div className="flex items-center gap-3">
              <Settings className="w-5 h-5 text-gray-400" />
              <span className="text-gray-700 font-medium">App Preferences</span>
            </div>
          </button>
          <button className="w-full flex items-center justify-between p-3 text-left hover:bg-gray-50 rounded-xl transition-colors">
            <div className="flex items-center gap-3">
              <HelpCircle className="w-5 h-5 text-gray-400" />
              <span className="text-gray-700 font-medium">Help & Support</span>
            </div>
          </button>
        </div>

        <button className="w-full flex items-center justify-center gap-2 p-4 text-red-600 font-medium hover:bg-red-50 rounded-2xl transition-colors border border-red-100 bg-white shadow-sm">
          <LogOut className="w-5 h-5" />
          Sign Out
        </button>
      </div>
    </div>
  );
}
