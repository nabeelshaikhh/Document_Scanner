'use client';

import React, { useState, useRef } from 'react';
import { UploadCloud, Camera, FileText, X, Loader2, CheckCircle2 } from 'lucide-react';
import { CameraCapture } from '@/components/CameraCapture';
import { GoogleGenAI } from '@google/genai';
import { useDocuments } from '@/lib/context';
import { useRouter } from 'next/navigation';
import { DocumentEditor } from '@/components/DocumentEditor';

export default function Dashboard() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState('');
  const [scannedText, setScannedText] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (file: File) => {
    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const clearSelection = () => {
    setSelectedFile(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setScannedText(null);
  };

  const handleScan = async () => {
    if (!selectedFile) return;

    setIsScanning(true);
    setScanProgress('Initializing AI model...');

    try {
      const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
      if (!apiKey) throw new Error('Gemini API key is missing');

      const ai = new GoogleGenAI({ apiKey });

      setScanProgress('Processing image...');
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(selectedFile);
      });
      const base64Data = await base64Promise;

      setScanProgress('Extracting text...');
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: selectedFile.type,
              },
            },
            {
              text: 'Extract all text from this image. Preserve formatting, paragraphs, and structure as much as possible. Output only the extracted text.',
            },
          ],
        },
      });

      setScanProgress('Finalizing...');
      setScannedText(response.text || '');
    } catch (error) {
      console.error('Scanning error:', error);
      alert('Failed to scan document. Please try again.');
    } finally {
      setIsScanning(false);
      setScanProgress('');
    }
  };

  if (isCameraOpen) {
    return (
      <CameraCapture
        onCapture={(file) => {
          processFile(file);
          setIsCameraOpen(false);
        }}
        onClose={() => setIsCameraOpen(false)}
      />
    );
  }

  if (scannedText !== null) {
    return (
      <DocumentEditor
        initialContent={scannedText}
        onDiscard={clearSelection}
      />
    );
  }

  return (
    <div className="p-6 flex flex-col min-h-screen">
      <header className="mb-8 mt-4">
        <h1 className="text-2xl font-bold text-gray-900">Document Scanner</h1>
        <p className="text-gray-500 text-sm mt-1">Scan, edit, and sign your documents</p>
      </header>

      {!selectedFile ? (
        <div className="flex-1 flex flex-col gap-6">
          <div
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-gray-300 rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-gray-50 transition-colors bg-white shadow-sm"
          >
            <div className="w-16 h-16 bg-indigo-50 rounded-full flex items-center justify-center mb-4">
              <UploadCloud className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">Upload Document</h3>
            <p className="text-sm text-gray-500 mb-4">Drag & drop or click to browse</p>
            <button className="px-6 py-2 bg-indigo-600 text-white rounded-full text-sm font-medium hover:bg-indigo-700 transition-colors">
              Select File
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              accept="image/*"
              className="hidden"
            />
          </div>

          <div className="relative flex items-center py-2">
            <div className="flex-grow border-t border-gray-200"></div>
            <span className="flex-shrink-0 mx-4 text-gray-400 text-sm">or</span>
            <div className="flex-grow border-t border-gray-200"></div>
          </div>

          <button
            onClick={() => setIsCameraOpen(true)}
            className="w-full bg-white border border-gray-200 rounded-2xl p-6 flex items-center justify-center gap-4 hover:bg-gray-50 transition-colors shadow-sm"
          >
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
              <Camera className="w-6 h-6 text-gray-700" />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-medium text-gray-900">Take Photo</h3>
              <p className="text-sm text-gray-500">Use your camera to scan</p>
            </div>
          </button>
        </div>
      ) : (
        <div className="flex-1 flex flex-col">
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden mb-6">
            <div className="relative aspect-[3/4] bg-gray-100 flex items-center justify-center">
              {previewUrl && (
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="max-w-full max-h-full object-contain"
                />
              )}
              <button
                onClick={clearSelection}
                className="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur rounded-full text-gray-700 hover:bg-white shadow-sm"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 flex items-center gap-3 border-t border-gray-100">
              <FileText className="w-8 h-8 text-indigo-500" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {selectedFile.name}
                </p>
                <p className="text-xs text-gray-500">
                  {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            </div>
          </div>

          {isScanning ? (
            <div className="flex flex-col items-center justify-center py-8">
              <Loader2 className="w-10 h-10 text-indigo-600 animate-spin mb-4" />
              <p className="text-gray-900 font-medium">{scanProgress}</p>
              <p className="text-sm text-gray-500 mt-1">This may take a few seconds</p>
            </div>
          ) : (
            <button
              onClick={handleScan}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-medium text-lg hover:bg-indigo-700 transition-colors shadow-md flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-5 h-5" />
              Scan Now
            </button>
          )}
        </div>
      )}
    </div>
  );
}
