'use client';

import React, { useState } from 'react';
import { useDocuments } from '@/lib/context';
import { FileText, Search, MoreVertical, Trash2, Download, Eye, X } from 'lucide-react';
import { useRouter } from 'next/navigation';
import jsPDF from 'jspdf';

export default function HistoryPage() {
  const { documents, deleteDocument } = useDocuments();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [viewingDoc, setViewingDoc] = useState<any | null>(null);
  const router = useRouter();

  const filteredDocs = documents.filter((doc) =>
    doc.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const exportPDF = (doc: any) => {
    const pdf = new jsPDF();
    pdf.setFontSize(16);
    pdf.text(doc.title, 20, 20);
    pdf.setFontSize(12);
    
    // Strip HTML tags for basic text export
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = doc.content;
    const plainText = tempDiv.innerText;
    
    const splitText = pdf.splitTextToSize(plainText, 170);
    pdf.text(splitText, 20, 30);
    
    if (doc.signature) {
      const yPos = Math.min(280, 30 + (splitText.length * 7) + 20);
      pdf.addImage(doc.signature, 'PNG', 20, yPos, 50, 25);
    }
    
    pdf.save(`${doc.title.replace(/\s+/g, '_')}.pdf`);
    setActiveMenu(null);
  };

  const exportTXT = (doc: any) => {
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = doc.content;
    const plainText = tempDiv.innerText;
    
    const blob = new Blob([plainText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${doc.title.replace(/\s+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    setActiveMenu(null);
  };

  return (
    <div className="p-6 flex flex-col min-h-screen bg-gray-50">
      <header className="mb-6 mt-4">
        <h1 className="text-2xl font-bold text-gray-900">History</h1>
        <p className="text-gray-500 text-sm mt-1">Your scanned documents</p>
      </header>

      <div className="relative mb-6">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          className="block w-full pl-10 pr-3 py-3 border border-gray-200 rounded-xl leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm transition-colors shadow-sm"
          placeholder="Search documents..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {filteredDocs.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <FileText className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-1">No documents found</h3>
          <p className="text-sm text-gray-500">
            {searchQuery ? 'Try adjusting your search' : 'Scan a document to get started'}
          </p>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto pb-24 space-y-3">
          {filteredDocs.map((doc) => (
            <div
              key={doc.id}
              className="bg-white border border-gray-200 rounded-xl p-4 flex items-center gap-4 shadow-sm relative"
            >
              <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center flex-shrink-0">
                <FileText className="w-6 h-6 text-indigo-600" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-base font-medium text-gray-900 truncate">{doc.title}</h4>
                <p className="text-xs text-gray-500 mt-0.5">
                  {new Date(doc.createdAt).toLocaleDateString()} • {doc.signature ? 'Signed' : 'Unsigned'}
                </p>
              </div>
              <button
                onClick={() => setActiveMenu(activeMenu === doc.id ? null : doc.id)}
                className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
              >
                <MoreVertical className="w-5 h-5" />
              </button>

              {/* Dropdown Menu */}
              {activeMenu === doc.id && (
                <div className="absolute right-4 top-14 w-48 bg-white rounded-xl shadow-lg border border-gray-100 z-10 py-1 overflow-hidden">
                  <button
                    onClick={() => {
                      setViewingDoc(doc);
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                  >
                    <Eye className="w-4 h-4" /> View Document
                  </button>
                  <button
                    onClick={() => exportPDF(doc)}
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" /> Save as PDF
                  </button>
                  <button
                    onClick={() => exportTXT(doc)}
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                  >
                    <FileText className="w-4 h-4" /> Save as TXT
                  </button>
                  <div className="h-px bg-gray-100 my-1"></div>
                  <button
                    onClick={() => {
                      deleteDocument(doc.id);
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" /> Delete
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* View Document Modal */}
      {viewingDoc && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
              <h3 className="font-medium text-gray-900 truncate pr-4">{viewingDoc.title}</h3>
              <button onClick={() => setViewingDoc(null)} className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-200">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1">
              <div 
                className="prose prose-sm max-w-none text-gray-800"
                dangerouslySetInnerHTML={{ __html: viewingDoc.content }}
              />
              {viewingDoc.signature && (
                <div className="mt-12 border-t border-gray-100 pt-8">
                  <p className="text-sm text-gray-400 mb-2">Signature:</p>
                  <img src={viewingDoc.signature} alt="Signature" className="h-20 object-contain" />
                </div>
              )}
            </div>
            <div className="p-4 border-t border-gray-100 bg-gray-50 flex gap-3">
              <button
                onClick={() => exportPDF(viewingDoc)}
                className="flex-1 py-2.5 bg-indigo-600 text-white font-medium rounded-xl hover:bg-indigo-700 flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" /> Export PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
