import type {Metadata} from 'next';
import './globals.css'; // Global styles
import { DocumentProvider } from '@/lib/context';
import { BottomNav } from '@/components/BottomNav';

export const metadata: Metadata = {
  title: 'Document Scanner',
  description: 'A minimalist productivity app to scan documents, extract text using AI, edit, sign, and export to PDF.',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body className="bg-gray-50 text-gray-900 antialiased" suppressHydrationWarning>
        <DocumentProvider>
          <main className="pb-20 min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-x-hidden relative">
            {children}
          </main>
          <BottomNav />
        </DocumentProvider>
      </body>
    </html>
  );
}
